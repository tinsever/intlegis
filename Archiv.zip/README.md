# IntLegis: International Treaty Database

IntLegis is a distributed document management system for international treaties, countries, and historical audit trails.

## 🚀 Installation

1.  **Upload**: Place all files on your PHP-enabled web server (PHP 8.1+).
2.  **Permissions**: Ensure the root directory is writable so the installer can create `config.php` and `data.sqlite`.
3.  **Run Setup**: Navigate to your site's URL. You will be automatically redirected to the `/install` wizard.
4.  **Configuration**:
    *   **SQLite**: Recommended for simple setups (no config needed).
    *   **MySQL**: Enter your host, database name, and credentials.
    *   **Primary Mode**: Choose this for your main instance where you will edit documents.
    *   **Secondary Mode**: Choose this for read-only mirrors. Enter the Primary URL to enable replication.

## 🛠 Developer Docs

### Creating a Custom Auth Provider

IntLegis supports pluggable authentication. To create your own (e.g., to sync with a forum or LDAP):

1.  Create a new PHP file in `src/auth/your_provider.php`.
2.  The file must **return an array** with three closures:

```php
<?php
// src/auth/my_forum.php

return [
    'currentUser' => function(): ?array {
        // Your logic to check if a user is logged in
        // Return ['id' => 1, 'username' => 'john_doe'] or null
        return $_SESSION['forum_user'] ?? null;
    },

    'login' => function(array $user): void {
        // Your logic to start a session
        $_SESSION['forum_user'] = $user;
    },

    'logout' => function(): void {
        // Your logic to end a session
        unset($_SESSION['forum_user']);
    }
];
```

3.  Update `config.php` to use your provider:
    `'auth' => ['provider' => 'my_forum']`

### Multi-Instance Replication

Instances can stay in sync using the built-in Replication API.
*   **Primary**: Exports a stream of audit logs and snapshots at `/api/sync`.
*   **Secondary**: Pulls and applies updates via `/api/pull-sync`.
*   **Automation**: To keep a secondary in sync automatically, set up a CRON job to call `curl https://your-replica.com/api/pull-sync` every minute.

### Database Support

IntLegis uses standard ANSI SQL. It currently supports:
*   **SQLite**: Zero-config, stored in a local file.
*   **MySQL / MariaDB**: Production-grade performance.

To switch backends, update the `db` section in your `config.php`.

